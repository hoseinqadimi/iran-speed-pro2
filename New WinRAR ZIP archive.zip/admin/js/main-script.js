/**
 * منطق مدیریت پنل ادمین ایران اسپید پرو
 */
document.addEventListener('DOMContentLoaded', function() {
    
    const tabs = document.querySelectorAll('.isp-tabs li');
    const contents = document.querySelectorAll('.isp-tab-content');

    // ۱. مدیریت کلیک روی تب‌ها
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const target = tab.getAttribute('data-tab');

            // حذف کلاس فعال از همه تب‌ها
            tabs.forEach(t => t.classList.remove('active'));
            // حذف کلاس فعال از همه محتواها
            contents.forEach(c => c.classList.remove('active'));

            // اضافه کردن کلاس فعال به تب کلیک شده
            tab.classList.add('active');
            
            // نمایش محتوای مربوطه
            const activeContent = document.getElementById(target);
            if (activeContent) {
                activeContent.classList.add('active');
            }
        });
    });

    // ۲. انیمیشن ساده برای کارت‌های داشبورد هنگام لود
    const cards = document.querySelectorAll('.isp-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.4s ease';
        
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100 * (index + 1));
    });
});