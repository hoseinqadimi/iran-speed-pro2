<?php
/**
 * ظاهر اصلی داشبورد افزونه (View)
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap isp-admin-wrapper">
    <header class="isp-header">
        <div class="isp-logo">
            <h1>ایران اسپید <span class="version">نسخه <?php echo ISP_VERSION; ?></span></h1>
        </div>
        <div class="isp-status">
            <span class="status-dot online"></span>
            وضعیت سیستم: هوشمند
        </div>
    </header>

    <div class="isp-container">
        <aside class="isp-sidebar">
            <ul class="isp-tabs">
                <li class="active" data-tab="dashboard">پیشخوان</li>
                <li data-tab="monitoring">مانیتورینگ منابع</li>
                <li data-tab="database">جراحی دیتابیس</li>
                <li data-tab="media">بهینه‌سازی رسانه</li>
                <li data-tab="network">زره ایران (شبکه)</li>
                <li data-tab="settings">تنظیمات کلی</li>
            </ul>
        </aside>

        <main class="isp-main-content">
            <section id="dashboard" class="isp-tab-content active">
                <h2>خلاصه وضعیت سرعت سایت</h2>
                <div class="isp-cards">
                    <div class="isp-card">
                        <h3>نمره سلامت</h3>
                        <div class="score">--</div>
                    </div>
                    <div class="isp-card">
                        <h3>جداول یتیم</h3>
                        <div class="count">در حال بررسی...</div>
                    </div>
                </div>
            </section>
        </main>
    </div>
</div>