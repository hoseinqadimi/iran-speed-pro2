<?php
/**
 * کلاس اصلی مدیریت (Admin)
 * وظیفه: ایجاد منوها، لود کردن استایل‌ها و مدیریت صفحات پنل افزونه.
 */

if (!defined('ABSPATH')) {
    exit;
}

class ISP_Admin {

    /**
     * نام افزونه برای نمایش در منوها
     */
    private $plugin_name;

    /**
     * نسخه افزونه
     */
    private $version;

    public function __construct() {
        $this->plugin_name = 'iran-speed-pro';
        $this->version = ISP_VERSION;
    }

    /**
     * ثبت قلاب‌های (Hooks) مربوط به بخش مدیریت
     */
    public function init() {
        // ۱. اضافه کردن منو به پیشخوان وردپرس
        add_action('admin_menu', array($this, 'add_plugin_admin_menu'));

        // ۲. فراخوانی استایل‌ها و اسکریپت‌های اختصاصی پنل
        add_action('admin_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    /**
     * ایجاد منوی اصلی و زیرمنوهای افزونه
     */
    public function add_plugin_admin_menu() {
        add_menu_page(
            'ایران اسپید پرو',         // عنوان صفحه
            'ایران اسپید',            // نام در منو
            'manage_options',        // سطح دسترسی (فقط مدیر)
            $this->plugin_name,      // شناسه منو
            array($this, 'display_plugin_admin_page'), // تابع نمایش محتوا
            'dashicons-performance', // آیکون منو (شبیه سرعت‌سنج)
            2                        // موقعیت در منو
        );
    }

    /**
     * لود کردن فایل‌های CSS برای ظاهر پنل
     */
    public function enqueue_styles($hook) {
        // فقط در صفحات مربوط به این افزونه استایل را لود کن
        if ($hook != 'toplevel_page_' . $this->plugin_name) {
            return;
        }

        wp_enqueue_style(
            $this->plugin_name,
            ISP_URL . 'admin/css/modern-ui.css',
            array(),
            $this->version,
            'all'
        );
    }

    /**
     * لود کردن فایل‌های JavaScript برای تعاملات پنل
     */
    public function enqueue_scripts($hook) {
        if ($hook != 'toplevel_page_' . $this->plugin_name) {
            return;
        }

        wp_enqueue_script(
            $this->plugin_name,
            ISP_URL . 'admin/js/main-script.js',
            array('jquery'),
            $this->version,
            false
        );
    }

    /**
     * فراخوانی فایل ویو (View) برای نمایش ظاهر اصلی پنل
     */
    public function display_plugin_admin_page() {
        require_once ISP_PATH . 'admin/views/dashboard.php';
    }
}